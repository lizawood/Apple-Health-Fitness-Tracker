from myfitness.summary import maxmin.getMax
from myfitness.summary import maxmin.getMin
