from setuptools import setup, find_packages

setup(
    name='myFitness',
    version='0.1',
    packages=find_packages(exclude=['tests*']),
    license='MIT',
    description='A test python package',
	url='https://github.com/khalad-hasan/myMileConverter',
    author='Liza Wood',
    author_email='liza.4.bc@gmail.com'
)
